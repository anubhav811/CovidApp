package com.anubhav.covidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PharmacistActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pharmacist);
    }
}